from django.shortcuts import render

# Create your views here.



def default_map(request):
    mapbox_access_token = 'pk.my_mapbox_access_token'

    return render(request, 'default.html',{ 'mapbox_access_token': mapbox_access_token })

def plasmodium_map(request):
    mapbox_access_token = 'pk.my_mapbox_access_token'

    return render(request, 'plasmodium.html',{ 'mapbox_access_token': mapbox_access_token })

def leishmania_map(request):
    mapbox_access_token = 'pk.my_mapbox_access_token'

    return render(request, 'leishmania.html',{ 'mapbox_access_token': mapbox_access_token })

def trypanosoma_map(request):
    mapbox_access_token = 'pk.my_mapbox_access_token'

    return render(request, 'trypanosoma.html',{ 'mapbox_access_token': mapbox_access_token })

def ascaris_lumbricoides_map(request):
    mapbox_access_token = 'pk.my_mapbox_access_token'

    return render(request, 'ascaris.html',{ 'mapbox_access_token': mapbox_access_token })

def trichinella_spiralis_map(request):
    mapbox_access_token = 'pk.my_mapbox_access_token'

    return render(request, 'trichinella.html',{ 'mapbox_access_token': mapbox_access_token })